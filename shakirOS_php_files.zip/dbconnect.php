<?php
$servername = "localhost";
$username = "id9115371_shakiros_user";
$password = "shakir2505";
$dbname = "id9115371_shakiros_data";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>